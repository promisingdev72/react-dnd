import Emulator from "../../components/Emulator/Emulator";

const Home = () => {
  return (
    <>
      <Emulator />
    </>
  );
};

export default Home;
